todo
====

* refactor schema generation/modification code into a DDL-only compiler
