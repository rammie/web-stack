========================
``lang.morph_en`` module
========================

.. automodule:: whoosh.lang.morph_en

.. autofunction:: variations
