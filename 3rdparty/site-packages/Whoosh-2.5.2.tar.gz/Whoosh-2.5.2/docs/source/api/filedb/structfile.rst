============================
``filedb.structfile`` module
============================

.. automodule:: whoosh.filedb.structfile

Classes
=======

.. autoclass:: StructFile
    :members:

.. autoclass:: BufferFile
.. autoclass:: ChecksumFile
