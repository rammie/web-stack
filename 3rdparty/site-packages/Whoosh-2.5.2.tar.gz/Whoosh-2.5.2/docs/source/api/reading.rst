==================
``reading`` module
==================

.. automodule:: whoosh.reading

Classes
=======

.. autoclass:: IndexReader
    :members:

.. autoclass:: MultiReader

.. autoclass:: TermInfo
   :members:

Exceptions
==========

.. autoexception:: TermNotFound

