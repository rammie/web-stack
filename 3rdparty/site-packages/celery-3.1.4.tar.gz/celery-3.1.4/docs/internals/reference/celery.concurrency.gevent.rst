=============================================================
 celery.concurrency.gevent† (*experimental*)
=============================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.gevent

.. automodule:: celery.concurrency.gevent
    :members:
    :undoc-members:
