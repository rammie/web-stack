====================================
 celery.worker.pidbox
====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.pidbox

.. automodule:: celery.worker.pidbox
    :members:
    :undoc-members:
