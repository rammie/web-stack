================================
 celery.app.log
================================

.. contents::
    :local:
.. currentmodule:: celery.app.log

.. automodule:: celery.app.log
    :members:
    :undoc-members:
