========================
 celery.security
========================

.. contents::
    :local:
.. currentmodule:: celery.security

.. automodule:: celery.security
    :members:
    :undoc-members:
