====================================
 celery.utils.mail
====================================

.. contents::
    :local:
.. currentmodule:: celery.utils.mail

.. automodule:: celery.utils.mail
    :members:
    :undoc-members:
