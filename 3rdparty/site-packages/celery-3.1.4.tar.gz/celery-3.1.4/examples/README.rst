=================
 Celery Examples
=================


* pythonproject

Example Python project using celery.

* httpexample

Example project using remote tasks (webhook tasks)

* celery_http_gateway

Example HTTP service exposing the ability to apply tasks and query the
resulting status/return value.

