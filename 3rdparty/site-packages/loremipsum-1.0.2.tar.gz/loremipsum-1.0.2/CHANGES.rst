1.0.2
   * Now is a package: fixes datafiles distribution.
1.0.1
   * Added support for python 2.5
1.0.0
   * Added unittests.
   * Added documentation.
   * Added stats to text generators methods in Generator
   * Added generator methods in Generator, for multiple text generations
   * Added stats-less text generators fuctions to module
    
0.1.0
   * First release.
