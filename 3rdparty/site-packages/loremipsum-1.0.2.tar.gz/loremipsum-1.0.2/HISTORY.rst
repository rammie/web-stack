Most of the code of this module is taken from `lorem-ipsum-generator`_ by James
Hales. James stated that his package served his purpose and he was not
interested in further development, so I took it over (to serve my purpose).

.. _`lorem-ipsum-generator`: http://code.google.com/p/lorem-ipsum-generator

