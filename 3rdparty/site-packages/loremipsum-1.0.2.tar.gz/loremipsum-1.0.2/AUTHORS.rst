Luca De Vitis <luca at monkeython dot org>
James Hales <jhales dot perth at gmail dot com> (original code author)
